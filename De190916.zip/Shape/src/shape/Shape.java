package shape;

public abstract class Shape {
    public abstract double getArea();
    public abstract void showResult();
}
