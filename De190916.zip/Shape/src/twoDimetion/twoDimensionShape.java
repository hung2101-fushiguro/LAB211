package twoDimetion;

import shape.Shape;

public abstract class twoDimensionShape extends Shape {
}
