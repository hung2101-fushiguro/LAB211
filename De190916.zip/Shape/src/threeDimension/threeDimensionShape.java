package threeDimension;

import shape.Shape;

public abstract class threeDimensionShape extends Shape {
    abstract double getVolume();
}
